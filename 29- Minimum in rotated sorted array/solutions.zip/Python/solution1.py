# By traversing the whole array:

# Time complexity: O(n)
# Space complexity: O(1)

def minimum(arr):
  return min(arr)



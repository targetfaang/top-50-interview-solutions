// By traversing the whole array:

// Time complexity: O(n)
// Space complexity: O(1)


function minimum(arr){
  return Math.min(...arr);
}


